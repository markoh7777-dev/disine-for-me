# web-design-skills

45 скилов для Claude Code про дизайн сайтов, анимации и 3D в одном репозитории.

## Установка одной командой

```bash
curl -fsSL https://raw.githubusercontent.com/GITHUB_USER/web-design-skills/main/install.sh | bash
```

Скилы копируются в `~/.claude/skills` и доступны во всех проектах. Чтобы поставить только в текущий проект:

```bash
curl -fsSL https://raw.githubusercontent.com/GITHUB_USER/web-design-skills/main/install.sh | bash -s -- --project
```

Обновление: та же команда ещё раз. После установки перезапусти Claude Code.

### Вариант через плагин

Внутри Claude Code:

```
/plugin marketplace add GITHUB_USER/web-design-skills
/plugin install web-design-skills@web-design-skills
```

Так скилы обновляются через `/plugin`, но вызываются с префиксом `web-design-skills:`.

## Что внутри

**Дизайн и вкус:** frontend-design, taste-skill, ui-ux-pro-max, modern-web-design, emil-design-eng, apple-design, design, ui-styling, design-system

**Бренд и графика:** brand, banner-design, slides

**Процесс дизайна:** design-critique, design-handoff, design-system-audit, accessibility-review, ux-copy, user-research, research-synthesis

**Прототипы, сборка, аудит:** prototype, pick-ui-library, web-artifacts-builder, site-audit

**Анимации и скролл:** gsap-scrolltrigger, motion-framer, react-spring-physics, animejs, lottie-animations, rive-interactive, barba-js, locomotive-scroll, scroll-reveal-libraries, animated-component-libraries, animate, improve-animations, review-animations, find-animation-opportunities, animation-vocabulary, ask-sonner

**3D и canvas:** threejs-webgl, react-three-fiber, web3d-integration-patterns, lightweight-3d-effects, spline-interactive, pixijs-2d

## Базовая связка для лендинга

taste-skill + modern-web-design + ui-ux-pro-max → gsap-scrolltrigger → site-audit перед сдачей.

> Часть скилов основана на сторонних материалах (например, emil-design-eng, taste-skill). Держи репозиторий приватным, если не уверен в лицензиях.
