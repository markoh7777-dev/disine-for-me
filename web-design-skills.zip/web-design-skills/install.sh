#!/usr/bin/env bash
# Installs all skills into ~/.claude/skills (or ./.claude/skills with --project)
set -euo pipefail
REPO_URL="${REPO_URL:-https://github.com/GITHUB_USER/web-design-skills.git}"
DEST="$HOME/.claude/skills"
[ "${1:-}" = "--project" ] && DEST="$(pwd)/.claude/skills"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
git clone --depth 1 -q "$REPO_URL" "$TMP/repo"
mkdir -p "$DEST"
count=0
for dir in "$TMP/repo/skills"/*/; do
  name="$(basename "$dir")"
  rm -rf "$DEST/$name"
  cp -R "$dir" "$DEST/$name"
  count=$((count+1))
done
echo "✓ Installed $count skills into $DEST — restart Claude Code to load them."
